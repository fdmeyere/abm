﻿#########################################
#
# Root script.
#
#########################################


# Download eerst het echte script
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri https://azurebackupmonitor.azurewebsites.net/repl/sendreplreport.ps1.html -OutFile c:\cce\sendreplreport.ps1

# Zet derdencode juist en draai het.

$derdencode="ALGIST"
Invoke-Expression c:\cce\sendreplreport.ps1