﻿#########################################
#
# Root script.
#
#########################################


# Download eerst het echte script

Invoke-WebRequest -Uri http://azurebackupmonitor.azurewebsites.net/dpm/senddpmreport.ps1.html -OutFile c:\cce\senddpmreport.ps1

# Zet derdencode juist en draai het.

$derdencode="DKIM001"
#Invoke-Expression c:\cce\senddpmreport.ps1